export const HOME = 'HOME'
export const ADD = 'ADD'
export const DETAILS = 'DETAILS'
export const GEO = 'GEO'







