import { LightTheme, DarkTheme } from "./ColorThemes";

export default {
  name: '',
  theme: {...LightTheme},
  openSetting: false
};
