export const SET_NAME = 'SET_NAME'
export const SET_THEME = 'SET_THEME'
export const SET_SETTING = 'SET_SETTING'



