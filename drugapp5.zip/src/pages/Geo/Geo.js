import { Text, View } from "react-native";
import React from 'react';

const Geo = () => {
  return <View>
    <Text style={{textAlign: 'center', margin: 30, fontSize: 20}}>В разработке</Text>
  </View>
}
export default Geo
