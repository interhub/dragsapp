export default [
  {
    value: 1,
    label: 'ПН'
  },
  {
    value: 2,
    label: 'ВТ'
  },
  {
    value: 3,
    label: 'СР'
  },
  {
    value: 4,
    label: 'ЧТ'
  },
  {
    value: 5,
    label: 'ПТ'
  },
  {
    value: 6,
    label: 'СБ'
  },
  {
    value: 0,
    label: 'ВС'
  },
]
